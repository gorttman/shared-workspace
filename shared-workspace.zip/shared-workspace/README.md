# shared-workspace

Shared Ansible role for loading dynamic variable files from a central location.
